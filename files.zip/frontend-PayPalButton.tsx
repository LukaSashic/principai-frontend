'use client';

import { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';

interface PayPalButtonProps {
  analysisId: string;
  amount?: number;
  currency?: string;
  onSuccess: (orderId: string) => void;
  onError: (error: string) => void;
}

export default function PayPalButton({
  analysisId,
  amount = 39.00,
  currency = 'EUR',
  onSuccess,
  onError
}: PayPalButtonProps) {
  const [loading, setLoading] = useState(false);
  const [paypalLoaded, setPaypalLoaded] = useState(false);

  useEffect(() => {
    // Load PayPal SDK
    if (typeof window !== 'undefined' && !(window as any).paypal) {
      const script = document.createElement('script');
      script.src = `https://www.paypal.com/sdk/js?client-id=${process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID}&currency=${currency}`;
      script.addEventListener('load', () => setPaypalLoaded(true));
      script.addEventListener('error', () => {
        onError('Failed to load PayPal SDK');
      });
      document.body.appendChild(script);
    } else {
      setPaypalLoaded(true);
    }
  }, [currency, onError]);

  useEffect(() => {
    if (!paypalLoaded || !(window as any).paypal) return;

    const paypal = (window as any).paypal;

    // Render PayPal Button
    paypal.Buttons({
      style: {
        layout: 'vertical',
        color: 'blue',
        shape: 'rect',
        label: 'pay'
      },
      
      createOrder: async () => {
        try {
          setLoading(true);
          
          const response = await fetch('http://localhost:8000/api/create-payment', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              analysis_id: analysisId,
              amount: amount,
              currency: currency
            })
          });

          if (!response.ok) {
            const error = await response.json();
            throw new Error(error.detail || 'Failed to create order');
          }

          const data = await response.json();
          return data.order_id;
          
        } catch (error: any) {
          onError(error.message || 'Payment creation failed');
          throw error;
        } finally {
          setLoading(false);
        }
      },

      onApprove: async (data: any) => {
        try {
          setLoading(true);
          onSuccess(data.orderID);
        } catch (error: any) {
          onError(error.message || 'Payment approval failed');
        }
      },

      onCancel: () => {
        setLoading(false);
        onError('Payment cancelled by user');
      },

      onError: (err: any) => {
        setLoading(false);
        onError('Payment error occurred');
        console.error('PayPal Error:', err);
      }
    }).render('#paypal-button-container');
  }, [paypalLoaded, analysisId, amount, currency, onSuccess, onError]);

  if (!paypalLoaded) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
        <span className="ml-3 text-gray-600">PayPal wird geladen...</span>
      </div>
    );
  }

  return (
    <div className="relative">
      {loading && (
        <div className="absolute inset-0 bg-white/80 flex items-center justify-center z-10 rounded-lg">
          <Loader2 className="w-6 h-6 animate-spin text-amber-500" />
        </div>
      )}
      <div id="paypal-button-container" className="min-h-[200px]"></div>
    </div>
  );
}
