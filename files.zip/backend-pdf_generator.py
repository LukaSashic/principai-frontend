"""
PDF Report Generator für GründerAI
Creates professional 5-page business plan analysis reports
Uses ReportLab for PDF generation
"""

import os
from datetime import datetime
from typing import Dict, List
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, Image, KeepTogether
)
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
from reportlab.pdfgen import canvas
from reportlab.graphics.shapes import Drawing, Circle
from reportlab.graphics import renderPDF


def get_risk_color(risk_level: str) -> colors.Color:
    """Get color for risk level"""
    risk_colors = {
        "LOW": colors.Color(0.13, 0.71, 0.51),      # Green #22B573
        "MEDIUM": colors.Color(0.96, 0.62, 0.04),   # Amber #F59E0B
        "HIGH": colors.Color(0.96, 0.39, 0.09),     # Orange #F56315
        "CRITICAL": colors.Color(0.92, 0.22, 0.20)  # Red #EA3833
    }
    return risk_colors.get(risk_level, colors.grey)


def get_severity_icon(severity: str) -> str:
    """Get icon/symbol for severity"""
    severity_icons = {
        "CRITICAL": "⊗",
        "HIGH": "⚠",
        "MEDIUM": "⚡"
    }
    return severity_icons.get(severity, "•")


def create_score_circle(canvas_obj, x, y, score: int, risk_level: str):
    """Draw score circle visualization"""
    # Outer circle (background)
    canvas_obj.setStrokeColor(colors.Color(0.89, 0.91, 0.94))  # Gray
    canvas_obj.setLineWidth(8)
    canvas_obj.setFillColor(colors.white)
    canvas_obj.circle(x, y, 50, fill=1, stroke=1)
    
    # Score arc
    color = get_risk_color(risk_level)
    canvas_obj.setStrokeColor(color)
    canvas_obj.setLineWidth(8)
    
    # Calculate arc angle (score percentage)
    angle = (score / 100) * 360
    canvas_obj.setLineCap(2)  # Round cap
    
    # Draw arc (counterclockwise from 90 degrees)
    if score > 0:
        canvas_obj.saveState()
        canvas_obj.translate(x, y)
        canvas_obj.rotate(90)
        path = canvas_obj.beginPath()
        path.arc(0, 0, 50, 0, angle)
        canvas_obj.drawPath(path, stroke=1, fill=0)
        canvas_obj.restoreState()
    
    # Score text
    canvas_obj.setFillColor(colors.Color(0.1, 0.1, 0.1))
    canvas_obj.setFont("Helvetica-Bold", 32)
    score_text = str(score)
    text_width = canvas_obj.stringWidth(score_text, "Helvetica-Bold", 32)
    canvas_obj.drawString(x - text_width/2, y - 12, score_text)
    
    # "/100" text
    canvas_obj.setFont("Helvetica", 14)
    canvas_obj.setFillColor(colors.Color(0.4, 0.4, 0.4))
    canvas_obj.drawString(x - 15, y - 30, "/100")


def generate_report_pdf(analysis_result: Dict, output_path: str = None) -> str:
    """
    Generate comprehensive PDF report
    
    Args:
        analysis_result: Analysis data from grant_calibration
        output_path: Optional custom output path
    
    Returns:
        str: Path to generated PDF file
    """
    # Create output directory if needed
    if not output_path:
        reports_dir = os.path.join(os.path.dirname(__file__), "reports")
        os.makedirs(reports_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = os.path.join(reports_dir, f"gruenderai_report_{timestamp}.pdf")
    
    # Create PDF
    doc = SimpleDocTemplate(
        output_path,
        pagesize=A4,
        rightMargin=2*cm,
        leftMargin=2*cm,
        topMargin=2*cm,
        bottomMargin=2*cm
    )
    
    # Styles
    styles = getSampleStyleSheet()
    
    # Custom styles
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=28,
        textColor=colors.Color(0.1, 0.1, 0.1),
        spaceAfter=12,
        alignment=TA_CENTER,
        fontName='Helvetica-Bold'
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=18,
        textColor=colors.Color(0.1, 0.1, 0.1),
        spaceAfter=12,
        spaceBefore=16,
        fontName='Helvetica-Bold'
    )
    
    subheading_style = ParagraphStyle(
        'CustomSubHeading',
        parent=styles['Heading3'],
        fontSize=14,
        textColor=colors.Color(0.2, 0.2, 0.2),
        spaceAfter=8,
        spaceBefore=12,
        fontName='Helvetica-Bold'
    )
    
    body_style = ParagraphStyle(
        'CustomBody',
        parent=styles['BodyText'],
        fontSize=11,
        textColor=colors.Color(0.2, 0.2, 0.2),
        spaceAfter=8,
        alignment=TA_JUSTIFY,
        leading=16
    )
    
    # Extract data
    score = analysis_result.get("score", 0)
    risk_level = analysis_result.get("risk_level", "MEDIUM")
    detected_industry = analysis_result.get("detected_industry", "Nicht erkannt")
    estimated_revenue = analysis_result.get("estimated_revenue", "N/A")
    benchmark_revenue = analysis_result.get("benchmark_revenue", "N/A")
    top_issues = analysis_result.get("top_issues", [])
    
    # Build content
    content = []
    
    # ====== PAGE 1: EXECUTIVE SUMMARY ======
    
    # Title
    content.append(Paragraph("Analyse-Ergebnis", title_style))
    content.append(Spacer(1, 0.3*cm))
    
    # Subtitle
    subtitle_text = f"Branche: {detected_industry}"
    content.append(Paragraph(subtitle_text, body_style))
    content.append(Spacer(1, 1*cm))
    
    # Score section header
    content.append(Paragraph("Grant Calibration Score", heading_style))
    content.append(Paragraph("Wahrscheinlichkeit der Genehmigung", body_style))
    content.append(Spacer(1, 0.5*cm))
    
    # Score circle will be added via canvas (see below)
    content.append(Spacer(1, 4*cm))
    
    # Risk level badge
    risk_color = get_risk_color(risk_level)
    risk_translations = {
        "LOW": "NIEDRIGES RISIKO",
        "MEDIUM": "MITTLERES RISIKO",
        "HIGH": "HOHES RISIKO",
        "CRITICAL": "KRITISCHES RISIKO"
    }
    risk_text = risk_translations.get(risk_level, risk_level)
    
    risk_table = Table(
        [[Paragraph(f"<b>{risk_text}</b>", body_style)]],
        colWidths=[6*cm]
    )
    risk_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), risk_color),
        ('TEXTCOLOR', (0, 0), (-1, -1), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 12),
        ('TOPPADDING', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ('ROUNDEDCORNERS', [8, 8, 8, 8]),
    ]))
    content.append(risk_table)
    content.append(Spacer(1, 1*cm))
    
    # Revenue comparison
    content.append(Paragraph("Umsatz-Vergleich", subheading_style))
    
    revenue_data = [
        ["", ""],
        ["Dein Plan:", estimated_revenue],
        ["IHK-Benchmark:", benchmark_revenue]
    ]
    revenue_table = Table(revenue_data, colWidths=[8*cm, 8*cm])
    revenue_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 0), (-1, -1), 11),
        ('FONTNAME', (0, 1), (0, -1), 'Helvetica-Bold'),
        ('TEXTCOLOR', (1, 1), (1, 1), colors.Color(0.1, 0.1, 0.1)),
        ('TEXTCOLOR', (1, 2), (1, 2), colors.Color(0.13, 0.71, 0.51)),
        ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
    ]))
    content.append(revenue_table)
    content.append(Spacer(1, 1*cm))
    
    # Summary
    content.append(Paragraph("Zusammenfassung", subheading_style))
    
    if score >= 70:
        summary_text = "Ihr Business Plan hat gute Chancen auf Genehmigung. Die identifizierten Punkte sollten dennoch optimiert werden, um die Erfolgswahrscheinlichkeit zu maximieren."
    elif score >= 50:
        summary_text = "Ihr Business Plan hat moderate Chancen auf Genehmigung. Die kritischen Punkte müssen unbedingt überarbeitet werden, bevor Sie den Antrag einreichen."
    else:
        summary_text = "Ihr Business Plan weist erhebliche Schwachstellen auf. Eine gründliche Überarbeitung ist notwendig, um eine Genehmigung zu erhalten. Wir empfehlen, alle kritischen Punkte zu beheben."
    
    content.append(Paragraph(summary_text, body_style))
    
    content.append(PageBreak())
    
    # ====== PAGE 2: TOP CRITICAL ISSUES TITLE ======
    
    content.append(Paragraph("Top 3 Critical Issues", title_style))
    content.append(Spacer(1, 0.5*cm))
    content.append(Paragraph(
        "Die folgenden Punkte wurden als kritisch für die Genehmigung identifiziert und sollten prioritär behoben werden:",
        body_style
    ))
    content.append(Spacer(1, 1*cm))
    
    # ====== PAGES 2-4: ISSUES (One per page or section) ======
    
    for idx, issue in enumerate(top_issues[:3], 1):
        # Issue header
        severity = issue.get("severity", "MEDIUM")
        severity_icon = get_severity_icon(severity)
        severity_color = get_risk_color(severity)
        
        issue_title = f"{severity_icon} {idx}. {issue.get('title', 'Issue')}"
        content.append(Paragraph(issue_title, heading_style))
        
        # Severity badge
        severity_translations = {
            "CRITICAL": "CRITICAL",
            "HIGH": "HIGH",
            "MEDIUM": "MEDIUM"
        }
        severity_text = severity_translations.get(severity, severity)
        
        severity_table = Table(
            [[Paragraph(f"<b>{severity_text}</b>", body_style)]],
            colWidths=[3*cm]
        )
        severity_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), severity_color),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('ROUNDEDCORNERS', [6, 6, 6, 6]),
        ]))
        content.append(severity_table)
        content.append(Spacer(1, 0.5*cm))
        
        # Description
        description = issue.get("description", "Keine Beschreibung verfügbar")
        content.append(Paragraph(description, body_style))
        content.append(Spacer(1, 0.5*cm))
        
        # Fix section
        fix = issue.get("fix", "Keine Lösung verfügbar")
        
        fix_box_data = [[Paragraph(f"<b>✓ So korrigierst du es:</b><br/><br/>{fix}", body_style)]]
        fix_box = Table(fix_box_data, colWidths=[16*cm])
        fix_box.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), colors.Color(0.94, 0.98, 0.96)),
            ('BOX', (0, 0), (-1, -1), 1, colors.Color(0.13, 0.71, 0.51)),
            ('TOPPADDING', (0, 0), (-1, -1), 12),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
            ('LEFTPADDING', (0, 0), (-1, -1), 12),
            ('RIGHTPADDING', (0, 0), (-1, -1), 12),
            ('ROUNDEDCORNERS', [8, 8, 8, 8]),
        ]))
        content.append(fix_box)
        content.append(Spacer(1, 1*cm))
        
        # Page break after each issue except last
        if idx < len(top_issues[:3]):
            content.append(PageBreak())
    
    # ====== PAGE 5: NEXT STEPS ======
    
    content.append(PageBreak())
    content.append(Paragraph("Nächste Schritte", title_style))
    content.append(Spacer(1, 0.5*cm))
    
    next_steps = [
        "Überarbeiten Sie Ihren Business Plan basierend auf den identifizierten Issues",
        "Nutzen Sie die bereitgestellten Fixes und IHK-Benchmarks",
        "Erstellen Sie realistische Finanzprognosen (Umsatz, Kosten, Break-Even)",
        "Definieren Sie Ihre Zielgruppe konkret und analysieren Sie den Wettbewerb",
        "Lassen Sie den Plan von einem Experten (IHK, Steuerberater) prüfen",
        "Reichen Sie den überarbeiteten Plan bei der Arbeitsagentur ein"
    ]
    
    for step in next_steps:
        content.append(Paragraph(f"• {step}", body_style))
        content.append(Spacer(1, 0.3*cm))
    
    content.append(Spacer(1, 1*cm))
    
    # Resources
    content.append(Paragraph("Hilfreiche Ressourcen", subheading_style))
    
    resources = [
        ("IHK Existenzgründung", "https://www.ihk.de/existenzgruendung"),
        ("Arbeitsagentur Gründungszuschuss", "https://www.arbeitsagentur.de/gruendungszuschuss"),
        ("DEHOGA Gastronomie-Kennzahlen", "https://www.dehoga-bundesverband.de"),
    ]
    
    for name, url in resources:
        content.append(Paragraph(f"• <b>{name}</b>: {url}", body_style))
        content.append(Spacer(1, 0.2*cm))
    
    content.append(Spacer(1, 2*cm))
    
    # Footer
    footer_text = """
    <b>PrincipalAI - GründerAI</b><br/>
    Business Plan Analyse für Gründungszuschuss<br/>
    info@principal.de | www.principal.de
    """
    content.append(Paragraph(footer_text, ParagraphStyle(
        'Footer',
        parent=body_style,
        alignment=TA_CENTER,
        fontSize=9,
        textColor=colors.Color(0.5, 0.5, 0.5)
    )))
    
    # Build PDF with custom canvas for score circle
    def add_score_circle(canvas_obj, doc_obj):
        """Add score circle to first page"""
        if doc_obj.page == 1:
            # Calculate center position for circle
            page_width = A4[0]
            x = page_width / 2
            y = A4[1] - 10*cm  # Position from top
            
            create_score_circle(canvas_obj, x, y, score, risk_level)
    
    doc.build(content, onFirstPage=add_score_circle, onLaterPages=lambda c, d: None)
    
    return output_path


def generate_report_from_analysis_id(analysis_id: str, analysis_data: Dict) -> str:
    """
    Convenience function to generate report from analysis ID
    
    Args:
        analysis_id: Unique analysis identifier
        analysis_data: Analysis result data
    
    Returns:
        str: Path to generated PDF
    """
    reports_dir = os.path.join(os.path.dirname(__file__), "reports")
    os.makedirs(reports_dir, exist_ok=True)
    
    output_path = os.path.join(reports_dir, f"report_{analysis_id}.pdf")
    return generate_report_pdf(analysis_data, output_path)
